Chevrolet Step Van 30 Mr. Whoopee (1985)
-------------------------------------------------------------
Особенности:
– Качественная аутентичная замена фургончика мороженщика;
– Масштаб автомобиля – 110% от первоначальной 3D модели;
– Поддержка 2-х цветов;
– Поддержка игрового номерного знака и стандартной цветовой схемы;
– Адаптация к «Improved Vehicle Features 2.1.1»;
– Собственная тень, коллизия, модель chassis_vlo;
– Реалистичные повреждения и управление;
– Адаптирован к модификации «HQLM 2.2»;
– Адаптирован к плагину «GFXHack 1.12»;
– Адаптирован к скрипту «Двери фургона 1.2».
-------------------------------------------------------------
Installation Anleitung:
-------------------------------------------------------------
1) Seite des Autors: vk.com/alfa_modding_studio
Der Autor: Pumbars, Spit811, Listik, Alex_SS
Ersetzt: Mr Whoopee
{tag_tag} Trucks
-------------------------------------------------------------
2) Importieren von Dateien in das Spiel-Archiv:
Mit dem Programm IMGTool 2.0 oder Crazy IMG Editor importieren Sie Dateien aus einem Ordner "To import to gta3.img" im Archiv [Ordner mit dem Spiel]\models\gta3.img

Die Download-Link fuer IMGTool 2.0 ist hier: https://GameModding.com/en/gta-san-andreas/gta-sa-programms/829-imgtool-20.html
Crazy IMG Editor hier: https://GameModding.com/en/gta-san-andreas/gta-sa-programms/828-gta-san-andreas-crazy-img-editor.html
-------------------------------------------------------------
3) Replacement-Optionen fuer den Transport (Nehmen Sie Aenderungen an Textdateien):

in der Datei - [Installationsordner]\data\handling.cfg
Ersetzen Sie die Zeile mit den Einstellungen mit:
MRWHOOP 5500.0 23489.6 3.0 0.0 0.0 0.00 80 0.82 0.70 0.46 5 140.0 14.0 25.0 R D 4.5 0.60 0 30.0 0.9 0.08 0.0 0.25 -0.25 0.4 0.6 0.46 0.40 22000 00004009 00000202 1 1 13

in der Datei - [Installationsordner]\data\vehicles.ide
Ersetzen Sie die Zeile mit den Einstellungen mit:
423, 	mrwhoop, 	mrwhoop, 	car, 		MRWHOOP, 	WHOOPEE, null, worker, 4, 1, 0, -1, 0.81, 0.81, -1

in der Datei - [Installationsordner]\data\carcols.dat
Ersetzen Sie die Zeile mit den Einstellungen mit:
mrwhoop, 1,7, 126,2, 7,77, 77,85, 73,113, 1,5, 93,61, 5,14
-------------------------------------------------------------
Diese Modifikation wurde von der Website https://GameModding.com/en/ heruntergeladen\r\nFolgen Sie uns in den sozialen Netzwerken!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
