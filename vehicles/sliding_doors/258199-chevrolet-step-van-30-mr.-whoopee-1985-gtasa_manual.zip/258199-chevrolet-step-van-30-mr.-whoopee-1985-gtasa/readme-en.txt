Chevrolet Step Van 30 Mr. Whoopee (1985)
-------------------------------------------------------------
Особенности:
– Качественная аутентичная замена фургончика мороженщика;
– Масштаб автомобиля – 110% от первоначальной 3D модели;
– Поддержка 2-х цветов;
– Поддержка игрового номерного знака и стандартной цветовой схемы;
– Адаптация к «Improved Vehicle Features 2.1.1»;
– Собственная тень, коллизия, модель chassis_vlo;
– Реалистичные повреждения и управление;
– Адаптирован к модификации «HQLM 2.2»;
– Адаптирован к плагину «GFXHack 1.12»;
– Адаптирован к скрипту «Двери фургона 1.2».
-------------------------------------------------------------
Installation instructions:
-------------------------------------------------------------
1) Author`s site: vk.com/alfa_modding_studio
Author: Pumbars, Spit811, Listik, Alex_SS
Replace: Mr Whoopee
{tag_tag} Trucks
-------------------------------------------------------------
2) Importing files into the game archive:
With the IMGTool 2.0 or Crazy IMG Editor program import files from the folder "To import to gta3.img" in the archive [Game folder]\models\gta3.img

You can download IMGTool 2.0 here: https://GameModding.com/en/gta-san-andreas/gta-sa-programms/829-imgtool-20.html
Crazy IMG Editor here:  https://GameModding.com/en/gta-san-andreas/gta-sa-programms/828-gta-san-andreas-crazy-img-editor.html
-------------------------------------------------------------
3) Replacement options for transport (Make changes to text files):

in the file - [Game folder]\data\handling.cfg
Replace the lines with the settings with:
MRWHOOP 5500.0 23489.6 3.0 0.0 0.0 0.00 80 0.82 0.70 0.46 5 140.0 14.0 25.0 R D 4.5 0.60 0 30.0 0.9 0.08 0.0 0.25 -0.25 0.4 0.6 0.46 0.40 22000 00004009 00000202 1 1 13

in the file - [Game folder]\data\vehicles.ide
Replace the lines with the settings with:
423, 	mrwhoop, 	mrwhoop, 	car, 		MRWHOOP, 	WHOOPEE, null, worker, 4, 1, 0, -1, 0.81, 0.81, -1

in the file - [Game folder]\data\carcols.dat
Replace the lines with the settings with:
mrwhoop, 1,7, 126,2, 7,77, 77,85, 73,113, 1,5, 93,61, 5,14
-------------------------------------------------------------
This modification was downloaded from https://GameModding.com/ website
Follow us in social networks!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
