(Sorry for if there are any grammar error or typing mistake because my english isnt perfect.)

Infernus Interceptor by Rafli.iN

List of Tweaking or Improved thing :

- Reworked Bodykit
- Adopted ImVehFt 2.1.2 (Reverse, Indicator, EML etc.)**Note : This is my first Adopted ImVehFt mod
- Moveable Spoiler
- etc.

Installation :
Put the files onto the corresponding path (.dff & .txd to gta3.img, ImVehFt's .eml to their path and so on)
NOTE : Dont forget to put the .eml file to ImVehFt path or your game will crashed.

To Handling.cfg :
POLICE_LA 1600.0 6500.0 1.9 0.0 0.3 -0.1 75 0.75 0.85 0.50 5 257.0 25.0 87.0 R P 10.0 0.53 0 35.0 1.0 0.12 0.0 0.28 -0.12 0.55 0.0 0.2 0.01 25000 40002000 01680008 0 0 0

If you have any suggestion or bugs, Contact me !

Credits :
R* for Base model of Infernus & Wheel Tyre
